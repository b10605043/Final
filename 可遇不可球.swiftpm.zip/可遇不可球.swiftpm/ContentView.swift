import SwiftUI

struct ContentView: View {
    @State private var results: [GameResult] = loadResults() // 初始從 UserDefaults 讀取資料
    
    var body: some View {
        TabView {
            // 行事曆頁面
            CalendarKitView()
                .tabItem {
                    Label("行事曆", systemImage: "calendar")
                }
            
            // 比賽計分板頁面
            ScoreBoardView(results: $results) // 傳遞 Binding 給 ScoreBoardViewa
                .tabItem {
                    Label("比賽", systemImage: "sportscourt")
                }
            
            // 比賽紀錄頁面
            ResultView(results: $results) // 傳遞 Binding 給 ResultView
                .tabItem {
                    Label("紀錄", systemImage: "chart.bar")
                }
        }
        .onChange(of: results) { oldResults, newResults in
            saveResults(newResults) // 每次 results 變更時，保存新資料到 UserDefaults
        }
    }
    
    // 儲存資料到 UserDefaults
    func saveResults(_ results: [GameResult]) {
        let encoder = JSONEncoder()
        if let encodedData = try? encoder.encode(results) {
            UserDefaults.standard.set(encodedData, forKey: "gameResults")
        }
    }
    
    // 從 UserDefaults 讀取資料
    static func loadResults() -> [GameResult] {
        let decoder = JSONDecoder()
        if let savedData = UserDefaults.standard.data(forKey: "gameResults"),
           let decodedResults = try? decoder.decode([GameResult].self, from: savedData) {
            return decodedResults
        }
        return [] // 如果沒有資料，回傳空陣列
    }
}
