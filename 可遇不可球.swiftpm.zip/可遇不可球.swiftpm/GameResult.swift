import Foundation

struct GameResult: Identifiable, Codable, Equatable {
    let id: UUID
    let player1Name: String
    let player2Name: String
    let winner: String
    let player1Score: Int
    let player2Score: Int
    let player1Sets: Int
    let player2Sets: Int
    let date: Date
}
