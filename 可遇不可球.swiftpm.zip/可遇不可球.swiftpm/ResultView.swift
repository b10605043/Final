import SwiftUI
import Charts

struct ResultView: View {
    @Binding var results: [GameResult]
    @State private var selectedResult: GameResult?
    
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 20) {
                    if results.isEmpty {
                        VStack(spacing: 16) {
                            Image(systemName: "chart.bar.doc.horizontal")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 80, height: 80)
                                .foregroundColor(.gray)
                            Text("尚無比賽結果")
                                .font(.title3)
                                .foregroundColor(.gray)
                        }
                        .padding(.top, 100)
                    } else {
                        Text("歷史比賽分數圖")
                            .font(.title2)
                            .fontWeight(.semibold)
                            .padding(.top)
                        
                        Chart(results) { result in
                            BarMark(
                                x: .value("選手", result.player1Name),
                                y: .value("得分", result.player1Score)
                            )
                            .foregroundStyle(Color.blue.gradient)
                            
                            BarMark(
                                x: .value("選手", result.player2Name),
                                y: .value("得分", result.player2Score)
                            )
                            .foregroundStyle(Color.green.gradient)
                        }
                        .chartYAxis {
                            AxisMarks(position: .leading)
                        }
                        .frame(height: 300)
                        .background(
                            RoundedRectangle(cornerRadius: 16)
                                .fill(Color(UIColor.systemBackground))
                                .shadow(radius: 2)
                        )
                        .padding()
                        
                        Text("比賽記錄")
                            .font(.title2)
                            .fontWeight(.bold)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.horizontal)
                        
                        LazyVStack(spacing: 15) {
                            ForEach(results) { result in
                                VStack(alignment: .leading, spacing: 8) {
                                    HStack {
                                        Text("\(result.player1Name)")
                                            .foregroundColor(.blue)
                                            .fontWeight(.semibold)
                                        Text("vs")
                                        Text("\(result.player2Name)")
                                            .foregroundColor(.green)
                                            .fontWeight(.semibold)
                                    }
                                    .font(.headline)
                                    
                                    Text("勝者：\(result.winner)")
                                        .foregroundColor(.orange)
                                    
                                    Text("比數：\(result.player1Score) - \(result.player2Score)")
                                    Text("時間：\(formattedDate(result.date))")
                                        .font(.footnote)
                                        .foregroundColor(.gray)
                                }
                                .padding()
                                .background(
                                    RoundedRectangle(cornerRadius: 12)
                                        .fill(selectedResult?.id == result.id ? Color.yellow.opacity(0.2) : Color(UIColor.secondarySystemBackground))
                                )
                                .overlay(
                                    RoundedRectangle(cornerRadius: 12)
                                        .stroke(selectedResult?.id == result.id ? Color.orange : Color.clear, lineWidth: 2)
                                )
                               
                                .onTapGesture {
                                    selectedResult = result
                                }
                                .animation(.easeInOut(duration: 0.2), value: selectedResult)
                                .padding(.horizontal)
                            }
                        }
                    }
                }
                .padding(.bottom, 30)
            }
            .navigationTitle("比賽結果")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    if !results.isEmpty {
                        Menu {
                            ForEach(results) { result in
                                Button(role: .destructive) {
                                    deleteResult(result)
                                } label: {
                                    Label("\(result.player1Name) vs \(result.player2Name)", systemImage: "trash")
                                }
                            }
                        } label: {
                            Label("刪除比賽", systemImage: "trash")
                        }
                    }
                }
            }
        }
    }
    
    func formattedDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }
    
    func deleteResult(_ result: GameResult) {
        if let index = results.firstIndex(where: { $0.id == result.id }) {
            results.remove(at: index)
            saveResults(results)
        }
    }
    
    func saveResults(_ results: [GameResult]) {
        let encoder = JSONEncoder()
        if let encodedData = try? encoder.encode(results) {
            UserDefaults.standard.set(encodedData, forKey: "gameResults")
        }
    }
}
