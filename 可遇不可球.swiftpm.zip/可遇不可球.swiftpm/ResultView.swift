import SwiftUI
import Charts

struct ResultView: View {
    @Binding var results: [GameResult] // 接收 ContentView 傳遞的資料
    @State private var selectedResult: GameResult? // 用於追蹤使用者選擇的比賽
    
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack {
                    if results.isEmpty {
                        Spacer()
                        Text("尚無比賽結果")
                            .font(.title2)
                            .foregroundColor(.gray)
                            .multilineTextAlignment(.center)
                            .frame(maxWidth: .infinity)
                        Spacer()
                    } else {
                        Chart(results) { result in
                            BarMark(
                                x: .value("選手", result.player1Name),
                                y: .value("分數", result.player1Score)
                            )
                            .foregroundStyle(Color.blue.gradient)
                            
                            BarMark(
                                x: .value("選手", result.player2Name),
                                y: .value("分數", result.player2Score)
                            )
                            .foregroundStyle(Color.green.gradient)
                        }
                        .frame(height: 300)
                        .padding()
                        
                        LazyVStack(spacing: 15) {
                            ForEach(results) { result in
                                VStack(alignment: .leading, spacing: 8) {
                                    Text("\(result.player1Name) vs \(result.player2Name)")
                                        .font(.headline)
                                    Text("勝者：\(result.winner)")
                                    Text("比數：\(result.player1Score) - \(result.player2Score)")
                                    Text("比賽時間：\(formattedDate(result.date))")
                                        .font(.footnote)
                                        .foregroundColor(.gray)
                                }
                                .padding()
                                .frame(maxWidth: .infinity)
                                .background(Color(UIColor.secondarySystemBackground))
                                .cornerRadius(10)
                                .shadow(radius: 2)
                                .padding(.horizontal)
                                .onTapGesture {
                                    selectedResult = result // 設定選擇的比賽
                                }
                            }
                        }
                    }
                }
                .padding()
                .frame(maxWidth: .infinity)
            }
            .navigationTitle("比賽結果")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Menu {
                        // 按下清除後，顯示所有比賽讓使用者選擇清除
                        ForEach(results) { result in
                            Button(action: {
                                deleteResult(result)
                            }) {
                                Text("\(result.player1Name) vs \(result.player2Name)")
                            }
                        }
                    } label: {
                        Label("清除", systemImage: "trash")
                    }
                }
            }
        }
    }
    
    // 格式化日期
    func formattedDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }
    
    // 刪除指定的比賽結果
    func deleteResult(_ result: GameResult) {
        if let index = results.firstIndex(where: { $0.id == result.id }) {
            results.remove(at: index) // 刪除指定的比賽
            saveResults(results) // 清除後儲存
        }
    }
    
    // 儲存結果到 UserDefaults
    func saveResults(_ results: [GameResult]) {
        let encoder = JSONEncoder()
        if let encodedData = try? encoder.encode(results) {
            UserDefaults.standard.set(encodedData, forKey: "gameResults")
        }
    }
}
