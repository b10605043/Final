import SwiftUI

struct SetupView: View {
    @State private var name1 = ""
    @State private var name2 = ""
    @State private var isReady = false
    @State private var showServeDecision = false
    
    @Binding var results: [GameResult]
    
    var body: some View {
        VStack(spacing: 20) {
            Text("輸入選手名稱")
                .font(.largeTitle)
                .fontWeight(.bold)
            
            TextField("選手 1 名稱", text: $name1)
                .padding()
                .background(Color(UIColor.secondarySystemBackground))
                .cornerRadius(8)
                .multilineTextAlignment(.center)
            
            TextField("選手 2 名稱", text: $name2)
                .padding()
                .background(Color(UIColor.secondarySystemBackground))
                .cornerRadius(8)
                .multilineTextAlignment(.center)
            
            Button(action: {
                if !name1.isEmpty && !name2.isEmpty {
                    showServeDecision = true
                }
            }) {
                Text("決定誰先發球")
                    .font(.headline)
                    .foregroundColor(.white)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(name1.isEmpty || name2.isEmpty ? Color.gray : Color.orange)
                    .cornerRadius(8)
            }
            .disabled(name1.isEmpty || name2.isEmpty)
        }
        .padding()
        .background(Color(UIColor.systemGroupedBackground))
        .cornerRadius(16)
        .padding()
        .sheet(isPresented: $showServeDecision) { // 改為使用 sheet
            ServeDecisionView(player1: name1, player2: name2, onDecision: { firstServer in
                // 根據決定的先發球選手，啟動比賽
                isReady = true
                if firstServer == name2 {
                    // 交換選手名稱，模擬先發球者
                    swap(&name1, &name2)
                }
            })
        }
        .fullScreenCover(isPresented: $isReady) { // 保留比賽畫面使用 fullScreenCover
            ScoreView(player1Name: name1, player2Name: name2, results: $results)
        }
    }
}

struct ServeDecisionView: View {
    var player1: String
    var player2: String
    var onDecision: (String) -> Void
    
    @State private var rotation: Double = 0
    @State private var isSpinning = false
    @State private var selectedPlayer: String?
    @State private var showScoreView = false // 控制計分版畫面
    
    var body: some View {
        VStack(spacing: 40) {
            Text("決定誰先發球")
                .font(.largeTitle)
                .fontWeight(.bold)
            
            ZStack {
                VStack {
                    Text(player1)
                        .font(.title)
                        .fontWeight(.bold)
                        .foregroundColor(.red)
                        .rotationEffect(.degrees(rotation))
                    Spacer().frame(height: 40) // 用於分隔兩個名稱
                    Text(player2)
                        .font(.title)
                        .fontWeight(.bold)
                        .foregroundColor(.blue)
                        .rotationEffect(.degrees(rotation))
                }
                .animation(.easeOut(duration: isSpinning ? 3 : 0), value: rotation)
            }
            
            Button(action: {
                if !isSpinning {
                    isSpinning = true
                    let randomAngle = Double.random(in: 720...1440) // 旋轉 2~4 圈
                    withAnimation {
                        rotation += randomAngle
                    }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                        // 根據最終角度決定選手
                        let angle = rotation.truncatingRemainder(dividingBy: 360)
                        selectedPlayer = (angle >= 0 && angle < 180) ? player1 : player2
                        isSpinning = false
                    }
                }
            }) {
                Text(isSpinning ? "旋轉中..." : "決定發球")
                    .font(.headline)
                    .foregroundColor(.white)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(isSpinning ? Color.gray : Color.orange)
                    .cornerRadius(8)
            }
            .disabled(isSpinning)
            
            if let winner = selectedPlayer, !isSpinning {
                VStack(spacing: 20) {
                    Text("\(winner) 先發球！")
                        .font(.title)
                        .foregroundColor(.red)
                    
                    Button(action: {
                        showScoreView = true // 跳轉到計分版畫面
                        onDecision(winner)
                    }) {
                        Text("按下此按鈕後點擊空白處以關閉")
                            .font(.headline)
                            .foregroundColor(.white)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color.green)
                            .cornerRadius(8)
                    }
                }
            }
        }
        .padding()
        .background(Color(UIColor.systemGroupedBackground))
        .cornerRadius(16)
        .padding()
    }
}

struct ScoreView: View {
    @State var player1Name: String
    @State var player2Name: String
    @Binding var results: [GameResult]
    
    @State private var player1Score = 0
    @State private var player2Score = 0
    @State private var player1Sets = 0
    @State private var player2Sets = 0
    @State private var showingWinnerAlert = false
    @State private var winner = ""
    
    @Environment(\.dismiss) var dismiss // 使用 dismiss 取代 presentationMode
    
    var body: some View {
        ZStack {
            Image("Table")
                .resizable()
                .scaledToFill()            
            VStack(spacing: 50) {
                HStack(spacing: 80) {
                    playerColumn(
                        name: player1Name,
                        score: player1Score,
                        sets: player1Sets,
                        actionAdd: { addPoint(toPlayer: 1) },
                        actionSubtract: { subtractPoint(toPlayer: 1) }
                    )
                    playerColumn(
                        name: player2Name,
                        score: player2Score,
                        sets: player2Sets,
                        actionAdd: { addPoint(toPlayer: 2) },
                        actionSubtract: { subtractPoint(toPlayer: 2) }
                    )
                }
                
                Button("重置比賽") {
                    resetMatch()
                }
                .foregroundColor(.red)
                .padding()
                .background(Color.white)
                .clipShape(RoundedRectangle(cornerRadius: 25))
                
                Button("主畫面") {
                    dismiss() // 正確關閉並回到 SetupView
                }
                .foregroundColor(.blue)
                .padding()
                .background(Color.white)
                .clipShape(RoundedRectangle(cornerRadius: 25))
            }
            .padding()
            .background(Color(UIColor.systemGroupedBackground).ignoresSafeArea())
            .alert(isPresented: $showingWinnerAlert) {
                Alert(
                    title: Text("比賽結束"),
                    message: Text("\(winner) 獲勝！"),
                    dismissButton: .default(Text("OK"), action: {
                        resetMatch()
                    })
                )
            }
        }
    }

    
    func playerColumn(name: String, score: Int, sets: Int, actionAdd: @escaping () -> Void, actionSubtract: @escaping () -> Void) -> some View {
        VStack(spacing: 40) {
            Text(name)
                .font(.title)
            Text("分數: \(score)")
                .font(.title)
                .padding()
            Text("局數: \(sets)")
                .font(.title)
                .padding()
            Button(action: actionAdd) {
                Text("＋1")
                    .font(.title)
                    .frame(width: 120, height: 90)
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .clipShape(RoundedRectangle(cornerRadius: 25))
            }
            Button(action: actionSubtract) {
                Text("-1")
                    .font(.title)
                    .frame(width: 120, height: 90)
                    .background(Color.red)
                    .foregroundColor(.white)
                    .clipShape(RoundedRectangle(cornerRadius: 25))
            }
        }
        .padding()
        .background(Color.white)
        .cornerRadius(10)
        .shadow(radius: 3)
    }
    
    func subtractPoint(toPlayer player: Int) {
        if player == 1, player1Score > 0 {
            player1Score -= 1
        } else if player == 2, player2Score > 0 {
            player2Score -= 1
        }
    }
    
    func addPoint(toPlayer player: Int) {
        if player == 1 { player1Score += 1 } else { player2Score += 1 }
        checkSetWin()
    }
    
    func checkSetWin() {
        if player1Score >= 11 && player1Score - player2Score >= 2 {
            player1Sets += 1
            prepareNextSet()
        } else if player2Score >= 11 && player2Score - player1Score >= 2 {
            player2Sets += 1
            prepareNextSet()
        }
        
        if player1Sets == 3 {
            winner = player1Name
            showingWinnerAlert = true
            saveResult(winner: player1Name)
        } else if player2Sets == 3 {
            winner = player2Name
            showingWinnerAlert = true
            saveResult(winner: player2Name)
        }
    }
    
    func prepareNextSet() {
        swap(&player1Name, &player2Name)
        swap(&player1Sets, &player2Sets)
        player1Score = 0
        player2Score = 0
    }
    
    func resetMatch() {
        player1Score = 0
        player2Score = 0
        player1Sets = 0
        player2Sets = 0
        winner = ""
        showingWinnerAlert = false
    }
    
    func saveResult(winner: String) {
        let result = GameResult(
            id: UUID(), player1Name: player1Name,
            player2Name: player2Name,
            winner: winner,
            player1Score: player1Sets,
            player2Score: player2Sets,
            player1Sets: player1Sets,
            player2Sets: player2Sets,
            date: Date()
        )
        
        // 更新本地 results 陣列
        results.append(result)
        
        // 保存到 UserDefaults
        saveResultsToUserDefaults(results)
    }
    
    // 保存 results 到 UserDefaults 的函數
    func saveResultsToUserDefaults(_ results: [GameResult]) {
        let encoder = JSONEncoder()
        if let encodedData = try? encoder.encode(results) {
            UserDefaults.standard.set(encodedData, forKey: "gameResults")
        }
    }
    
    // 從 UserDefaults 讀取 results 的函數
    func loadResultsFromUserDefaults() -> [GameResult] {
        let decoder = JSONDecoder()
        if let savedData = UserDefaults.standard.data(forKey: "gameResults"),
           let decodedResults = try? decoder.decode([GameResult].self, from: savedData) {
            return decodedResults
        }
        return [] // 如果沒有資料，回傳空陣列
    }
}

struct ScoreBoardView: View {
    @Binding var results: [GameResult]
    
    var body: some View {
        SetupView(results: $results)
    }
}
