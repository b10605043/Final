import SwiftUI
import CalendarView

struct CalendarKitView: View {
    @Environment(\.calendar) var calendar
    @State private var visibleComponents = Calendar.current.dateComponents([.year, .month], from: Date())
    @State private var selectedDate: DateComponents?
    @State private var events: [Date: [String]] = [:]  // 支援多活動
    
    @State private var showingAddEventDialog = false
    @State private var showingEventDetailDialog = false
    @State private var newEventTitle = ""
    @State private var selectedDateString = ""
    @State private var selectedDateKey: Date?
    
    var body: some View {
        ZStack {
            // CalendarView 全螢幕
            CalendarView(visibleDateComponents: $visibleComponents, selection: $selectedDate)
                .decorating(Set(events.keys.map { calendar.dateComponents([.year, .month, .day], from: $0) }),
                            systemImage: "star.fill", color: .blue)
                .onChange(of: selectedDate) { newDate in
                    if let dateComponents = newDate,
                       let date = calendar.date(from: dateComponents) {
                        selectedDateString = formatDate(date)
                        selectedDateKey = date
                        selectedDate = dateComponents
                        if events[date]?.isEmpty == false {
                            showingEventDetailDialog = true
                        } else {
                            newEventTitle = ""
                            showingAddEventDialog = true
                        }
                    }
                }
                .ignoresSafeArea() // 延伸到邊界
        }
        .onAppear {
            loadEvents()
        }
        // 新增活動對話框
        .alert("新增活動", isPresented: $showingAddEventDialog, actions: {
            TextField("輸入活動名稱", text: $newEventTitle)
            Button("新增") {
                if let date = selectedDateKey, !newEventTitle.isEmpty {
                    events[date, default: []].append(newEventTitle)
                    saveEvents()
                }
            }
            Button("取消", role: .cancel) {}
        }, message: {
            Text("為 \(selectedDateString) 新增活動")
        })
        // 查看活動（可刪除）
        .sheet(isPresented: $showingEventDetailDialog) {
            NavigationView {
                List {
                    if let date = selectedDateKey, let dayEvents = events[date] {
                        ForEach(dayEvents, id: \.self) { event in
                            Text(event)
                        }
                        .onDelete { indexSet in
                            if let index = indexSet.first {
                                events[date]?.remove(at: index)
                                if events[date]?.isEmpty == true {
                                    events.removeValue(forKey: date)
                                }
                                saveEvents()
                            }
                        }
                    } else {
                        Text("無活動")
                    }
                }
                .navigationTitle("\(selectedDateString) 的活動")
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) {
                        Button("關閉") {
                            showingEventDetailDialog = false
                        }
                    }
                    ToolbarItem(placement: .confirmationAction) {
                        Button("新增活動") {
                            showingEventDetailDialog = false
                            newEventTitle = ""
                            showingAddEventDialog = true
                        }
                    }
                }
            }
        }
    }
    
    // Date 轉字串格式
    private func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.locale = Locale(identifier: "zh_TW")
        return formatter.string(from: date)
    }
    
    // 保存到 UserDefaults
    private func saveEvents() {
        let encoder = JSONEncoder()
        if let data = try? encoder.encode(events) {
            UserDefaults.standard.set(data, forKey: "savedEvents")
        }
    }
    
    // 從 UserDefaults 加載
    private func loadEvents() {
        let decoder = JSONDecoder()
        if let data = UserDefaults.standard.data(forKey: "savedEvents"),
           let decoded = try? decoder.decode([Date: [String]].self, from: data) {
            events = decoded
        }
    }
}
